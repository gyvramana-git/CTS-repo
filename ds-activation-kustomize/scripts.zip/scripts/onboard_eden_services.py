# onboard all eden services

import os
import json
from pathlib import Path

with open(os.path.join(Path.home(), ".config", "ds_activation_kustomize_config.json")) as cfg_file:
    cfg_data = json.load(cfg_file)

    # kustomize version
    kustomize_version = "v1"

    # local directory paths
    kustomize_dir_base_path = cfg_data["kustomizeDirBasePath"]

    stateless_dir_path = os.path.join(kustomize_dir_base_path, kustomize_version, "apps", "stateless")
    stateful_dir_path = os.path.join(kustomize_dir_base_path, kustomize_version, "apps", "stateful")
    
    deployment_canary_template_path = os.path.join(kustomize_dir_base_path, kustomize_version, "templates", "deployment-template-java-canary")
    deployment_template_path = os.path.join(kustomize_dir_base_path, kustomize_version, "templates", "deployment-template-java")
    statefulset_template_path = os.path.join(kustomize_dir_base_path, kustomize_version, "templates", "statefulset-template-java")


    with open(os.path.join(kustomize_dir_base_path, "eden_services.json")) as f:
        data = json.load(f)
        for app in data:
            new_service = app["serviceName"]

            stateful = app["stateful"]

            image = app["image"]

            # label, do not modify
            labels = ["java-service-label-qa1", "java-service-label-qa2", "java-service-label-qa3", 
                    "java-service-label-ut-mdn", "java-service-label-ut-reno", "java-service-label-perf", 
                    "java-service-label-stg", "java-service-label-prod-mdn", "java-service-label-prod-reno"]

            vips = app["vips"]

            ############### User Input Ends ###############

            image = image.replace("/", "\/" )

            print("check if service already onboarded...")

            already_exists = list()

            # check if the service kustomize already exists
            if not stateful:
                for app in os.walk(stateless_dir_path):
                    already_exists = app[1]
                    break
            else:
                for app in os.walk(stateful_dir_path):
                    already_exists = app[1]
                    break

            #print(already_exists)

            # create using template if does not exist
            if new_service not in already_exists:
                print("onboarding service...")
                
                if not stateful:
                    print("stateless service, using k8s deployment template...")
                    src_base_path = deployment_template_path
                    dest_base_path = stateless_dir_path
                else:
                    print("stateful service, using k8s statefulset template...")
                    src_base_path = statefulset_template_path
                    dest_base_path = stateful_dir_path

                copy_cmd = os.system("cp -r " + src_base_path + " " + dest_base_path + "/" + new_service)
                print("`cp -r " + src_base_path + " to " + dest_base_path + "%s` ran with exit code %d" % (new_service, copy_cmd))

                if int(copy_cmd) == 0:
                    print("preparing the copied template for use...")
                    
                    for cnt, label in enumerate(labels):
                        patch_vip_alias = os.system("find " + dest_base_path + "/" + new_service + " -type f | xargs sed -i '' 's/" + label +"/" + vips[cnt] + "/g'")
                        if int(patch_vip_alias) != 0:
                            print("unable to patch the vip alias")

                    patch_image = os.system("find " + dest_base_path + "/" + new_service + " -type f | xargs sed -i '' 's/java-service-image/" + image + "/g'")
                    if int(patch_image) != 0:
                        #print("`find %s  -type f | xargs sed -i '' 's/java-service-image/%s/g'` ran with exit code %d" % (new_service, image, copy_cmd))
                        print("unable to patch the image name")

                    patch_name = os.system("find " + dest_base_path + "/" + new_service + " -type f | xargs sed -i '' 's/java-service/" + new_service + "/g'")
                    if int(patch_name) != 0:
                        print("unable to patch the service name")
                    
                    if not stateful:
                        # canary
                        copy_canary_cmd = os.system("cp -r " + deployment_canary_template_path + " " + dest_base_path + "/" + new_service + "-canary")
                        print("`cp -r " + deployment_canary_template_path + " to " + dest_base_path + "%s` ran with exit code %d" % (new_service, copy_canary_cmd))
                        
                        if int(copy_canary_cmd) == 0:
                            patch_name_canary = os.system("find " + dest_base_path + "/" + new_service + "-canary" + " -type f | xargs sed -i '' 's/java-service/" + new_service + "/g'")
                            if int(patch_name_canary) != 0:
                                print("unable to patch the service name")
                        
                    print("onboarding finished")    
                else:
                    print("copy errored out...")  
            else:
                print("service already exists: ", new_service)