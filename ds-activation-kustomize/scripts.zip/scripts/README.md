# Eden Services Onboarding Scripts

**NOTE:** This should only be used in case the application self-onboarding is not working in the developer portal or there is a change in the bases or templates. Also do not manually modify the kustomize at application level. All modifications should happen at the template or base level. Do get all modifications reviewed.

## How to use

### One-Time Setup (Pre-Requisite)

1. Run the following command: `mkdir -p ~/.config/`
2. Run the following command: `cp ds_activation_kustomize_config.json ~/.config/`
3. Modify the configuration file `~/.config/ds_activation_kustomize_config.json` and add the local path of the ds-activation-kustomize path to it

### Onboard a new service

1. Modify the following file with the details of the new application: `{ds-activation-kustomize path}/notebooks/eden_services.json`
2. Run the following command: `python3 onboard_eden_services.py`

### Propagate a change in the template or base to all applications

1. Run the following command if deployment-template was changed: `rm -rf {ds-activation-kustomize path}/v1/apps/stateless/*`
2. Run the following command is statefulset-template was changed: `rm -rf {ds-activation-kustomize path}/v1/apps/stateful/*`
3. Run the following command:  `python3 onboard_eden_services.py`
