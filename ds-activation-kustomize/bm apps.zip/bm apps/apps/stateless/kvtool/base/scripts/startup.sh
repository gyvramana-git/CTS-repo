#!/bin/sh
set -e

/ngs/app/pesdkr/tools/httpd/bin/apachectl start

tail -f /dev/null
