#!/bin/sh
set -e

/ngs/app/pesdkr/tools/httpd/bin/apachectl stop
