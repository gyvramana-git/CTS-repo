#!/bin/bash
set -e

# Getting properties
echo "!!! Dowloading properties just a second..... !!!"

APP=$2
ENV=$3
BUILD=$4


deploy() {

cd /apps/etc/private

token=$(grep 'token' token.txt | awk '{print $NF}')

if [ $ENV == "PROD" ]
then
echo "entering prod"
curl -L -u "pesds_bot:$token" -X GET https://artifacts.apple.com/artifactory/ds-iscloud-migration-generic-local/nastool${BUILD}.tar.gz -o nastool.tar.gz
else
echo "entering nonprod"
curl -L -u "pesds_bot:$token" -X GET https://artifacts.apple.com/artifactory/ds-iscloud-migration-generic-local/nastool${BUILD}.tar.gz -o nastool.tar.gz
fi

du -sh nastool.tar.gz

tar -zxvf nastool.tar.gz

rm nastool.tar.gz
chmod 644 requirements.txt | echo "Ignoring error if it is not present"
chmod 600 nastool.pem
chmod 600 nastool.key
chmod 600 mod*

ls -ltr

du -sh *

cp nastool.conf /ngs/app/pesdkr/tools/httpd/conf.d

ln -s /apps/etc/private/libnastool_dyn.so /ngs/app/pesdkr/tools/httpd/lib/libnastool_dyn.so | echo "Ignoring if not present"

cd /ngs/app/pesdkr/bin/

echo $pwd

./startup.sh

}

stop() {

cd /ngs/app/pesdkr/bin/

echo $pwd

./stop.sh

}


restart() {

cd /ngs/app/pesdkr/bin/

echo $pwd

./restart.sh

}


###################################
# Main Script Logic Starts Here   #
###################################

case "$1" in

  deploy)
        deploy
        ;;
  start)
        start
        ;;
  restart)
        restart
        ;;


  *)
        echo $"Usage: $prog {deploy|start|restart}"
        exit 1
esac
