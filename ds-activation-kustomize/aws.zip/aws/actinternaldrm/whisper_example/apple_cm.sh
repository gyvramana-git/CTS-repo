#!/bin/bash
set -eo pipefail

########################################################################################################################
# Constants
########################################################################################################################

USAGE=$(cat <<EOF
Usage: ./apple_cm.sh [-h|--help]
                       [-sp|--skip-private-ca]
                       [-cmh|--certmgr-host <certmgr_host>]
                       [-ou|--custom-ou <custom_ou>]
                       [-d|--description <description>]
                       [-cn|--ra-cn <ra_cn>]
                       [-pca|--private-ca-id <private_ca_id>]
                       [-ns|--ra-k8s-namespace <ra_k8s_namespace>]
                       [-ad|-admin-group-dsid <admin-group-dsid>]
                       -ra|-ra-group-dsid <ra-group-dsid>

Request a new RA certificate (PEM format) from Apple Certificate Manager
and optionally add to kubernetes secrets. Additionally, can create a
Private CA in Apple Certificate Manager and assign the RA for it.

mandatory arguments:
  -ra,  --ra-group-dsid     The DSID of the RA group.

conditional arguments:
  -ad,  --admin-group-dsid  The DSID of the admin group for the Private CA.
                            Required when --skip-private-ca is NOT provided.

optional arguments:
  -cmh, --certmgr-host      Certificate Manager host. Defaults to
                            certificatemanager.apple.com.
  -cn,  --ra-cn             CN for the RA credential. When provided, will be
                            present in the Subject DN of the RA. Defaults to
                            "RA for Apple Certificate Manager".
  -d,   --description       Description for the Private CA. Does not appear in
                            the Private CA certificate.
  -ou,  --custom-ou         Custom OU for the Private CA. When provided, will
                            be present in the Subject DN of the Private CA.
  -pca, --private-ca-id     Private CA ID. When provided, will try to add RA
                            to this private CA.
  -ns,  --ra-k8s-namespace  Kubernetes namespace to run RA. When provided,
                            will store generated RA credentials to a secrets
                            object in the same namespace.

options/flags:
  -h,   --help              Show this help message and exit.
  -sp,  --skip-private-ca   Skip Private CA related tasks. When provided, only
                            RA credentials will be created / added.
EOF
)
readonly USAGE

########################################################################################################################
# Global Variables
########################################################################################################################

quiet="0"
# Apple Root CA
# - Apple Corporate Root CA
# - Apple Corporate Root CA 2
# - Apple Corporate Root CA 3
readonly APPLE_ROOT_CAS="-----BEGIN CERTIFICATE-----
MIIDsTCCApmgAwIBAgIIFJlrSmrkQKAwDQYJKoZIhvcNAQELBQAwZjEgMB4GA1UE
AwwXQXBwbGUgQ29ycG9yYXRlIFJvb3QgQ0ExIDAeBgNVBAsMF0NlcnRpZmljYXRp
b24gQXV0aG9yaXR5MRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzAe
Fw0xMzA3MTYxOTIwNDVaFw0yOTA3MTcxOTIwNDVaMGYxIDAeBgNVBAMMF0FwcGxl
IENvcnBvcmF0ZSBSb290IENBMSAwHgYDVQQLDBdDZXJ0aWZpY2F0aW9uIEF1dGhv
cml0eTETMBEGA1UECgwKQXBwbGUgSW5jLjELMAkGA1UEBhMCVVMwggEiMA0GCSqG
SIb3DQEBAQUAA4IBDwAwggEKAoIBAQC1O+Ofah0ORlEe0LUXawZLkq84ECWh7h5O
7xngc7U3M3IhIctiSj2paNgHtOuNCtswMyEvb9P3Xc4gCgTb/791CEI/PtjI76T4
VnsTZGvzojgQ+u6dg5Md++8TbDhJ3etxppJYBN4BQSuZXr0kP2moRPKqAXi5OAYQ
dzb48qM+2V/q9Ytqpl/mUdCbUKAe9YWeSVBKYXjaKaczcouD7nuneU6OAm+dJZcm
hgyCxYwWfklh/f8aoA0o4Wj1roVy86vgdHXMV2Q8LFUFyY2qs+zIYogVKsRZYDfB
7WvO6cqvsKVFuv8WMqqShtm5oRN1lZuXXC21EspraznWm0s0R6s1AgMBAAGjYzBh
MB0GA1UdDgQWBBQ1ICbOhb5JJiAB3cju/z1oyNDf9TAPBgNVHRMBAf8EBTADAQH/
MB8GA1UdIwQYMBaAFDUgJs6FvkkmIAHdyO7/PWjI0N/1MA4GA1UdDwEB/wQEAwIB
BjANBgkqhkiG9w0BAQsFAAOCAQEAcwJKpncCp+HLUpediRGgj7zzjxQBKfOlRRcG
+ATybdXDd7gAwgoaCTI2NmnBKvBEN7x+XxX3CJwZJx1wT9wXlDy7JLTm/HGa1M8s
Errwto94maqMF36UDGo3WzWRUvpkozM0mTcAPLRObmPtwx03W0W034LN/qqSZMgv
1i0use1qBPHCSI1LtIQ5ozFN9mO0w26hpS/SHrDGDNEEOjG8h0n4JgvTDAgpu59N
CPCcEdOlLI2YsRuxV9Nprp4t1WQ4WMmyhASrEB3Kaymlq8z+u3T0NQOPZSoLu8cX
akk0gzCSjdeuldDXI6fjKQmhsTTDlUnDpPE2AAnTpAmt8lyXsg==
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
MIICRTCCAcugAwIBAgIIE0aVDhdcN/0wCgYIKoZIzj0EAwMwaDEiMCAGA1UEAwwZ
QXBwbGUgQ29ycG9yYXRlIFJvb3QgQ0EgMjEgMB4GA1UECwwXQ2VydGlmaWNhdGlv
biBBdXRob3JpdHkxEzARBgNVBAoMCkFwcGxlIEluYy4xCzAJBgNVBAYTAlVTMB4X
DTE2MDgxNzAxMjgwMVoXDTM2MDgxNDAxMjgwMVowaDEiMCAGA1UEAwwZQXBwbGUg
Q29ycG9yYXRlIFJvb3QgQ0EgMjEgMB4GA1UECwwXQ2VydGlmaWNhdGlvbiBBdXRo
b3JpdHkxEzARBgNVBAoMCkFwcGxlIEluYy4xCzAJBgNVBAYTAlVTMHYwEAYHKoZI
zj0CAQYFK4EEACIDYgAE6ROVmqXFAFCLpuLD3loNJwfuxX++VMPgK5QmsUuMmjGE
/3NWOUGitN7kNqfq62ebPFUqC1jUZ3QzyDt3i104cP5Z5jTC6Js4ZQxquyzTNZiO
emYPrMuIRYHBBG8hFGQxo0IwQDAdBgNVHQ4EFgQU1u/BzWSVD2tJ2l3nRQrweevi
XV8wDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAQYwCgYIKoZIzj0EAwMD
aAAwZQIxAKJCrFQynH90VBbOcS8KvF1MFX5SaMIVJtFxmcJIYQkPacZIXSwdHAff
i3+/qT+DhgIwSoUnYDwzNc4iHL30kyRzAeVK1zOUhH/cuUAw/AbOV8KDNULKW1Nc
xW6AdqJp2u2a
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
MIIFhTCCA22gAwIBAgIUcq4V0xpX0K4oAn9EyM6pTpuoKwswDQYJKoZIhvcNAQEM
BQAwSjELMAkGA1UEBhMCVVMxEzARBgNVBAoTCkFwcGxlIEluYy4xJjAkBgNVBAMT
HUFwcGxlIENvcnBvcmF0ZSBSU0EgUm9vdCBDQSAzMB4XDTIxMDIxNzE5MzAzMVoX
DTQxMDIxMzAwMDAwMFowSjELMAkGA1UEBhMCVVMxEzARBgNVBAoTCkFwcGxlIElu
Yy4xJjAkBgNVBAMTHUFwcGxlIENvcnBvcmF0ZSBSU0EgUm9vdCBDQSAzMIICIjAN
BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAwLsOaWB6T5qq58bICdbu6HBXPx9t
Y0M2i6V8xtLQbJQqM8gGALEsPyvUhOBACmPCoaafeKjx4++IjHi4Hn+j14OFg7J8
w6yr2f8mW7d47LoIkOt9OeqGhdZi/VU38oJd7qEye7hk6kCFhagOzBNJ1DILHPb4
04C2XGat4tUMFGzUlmQ3wsJIINIpq9jevasz+uA29GGPTgVMkWlqwNtxw74GoqF4
jnNmno5/W8M6cyzjh3AGZU3DWHfr3ZvACUVftJsm/htsoCNm0sr5t/iXClu6+STO
nmR3Leiq1w40kSFnD9obTs884U+iq49kr2tteSSvZV53YHuxkaBIG92wGOMyYhZ9
q3AluVokLHjOGW6tN/seFP0b51gOl/p+mDDLA3fSG5RuuMqjvHQXiSiBu5OTCtCd
8cbyPhiSAvYl0rhsWeYItcwWflVCUB7HAy/qlwicNo9aE0aSaN/3qmU4TzXW8H70
lbh6A2cKxGr9+y479d/DLGfcFj89wvmrhHrW3mZIgVwVjV49BfLed1Swihezit/a
CPQ0WF17FfqxIedVPusdjcfeT6BCU/X/+cq0sv06CiFZ4KNmDOn2XLii82xfMcj1
xWE+HufMWDuwS5DHJt0ttbknD1togzPBxaEu1/nIqZ5kYVUkCi+YXJQihaX+F5aJ
kacwlGPAmIBrMLcCAwEAAaNjMGEwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
gBSNX/LRHQdiX1xtg8SPTXcr6sPmqjAdBgNVHQ4EFgQUjV/y0R0HYl9cbYPEj013
K+rD5qowDgYDVR0PAQH/BAQDAgEGMA0GCSqGSIb3DQEBDAUAA4ICAQAOvvN+Prwt
KG2fROheiSw4scNk0WXcczWpUvYQKtMw5FzYofA28AYoE/HT2qQXFldMq+FlJ0v/
sWVkXWB3X9RQltUXZ0RLVdw7/ZGXzUZh7ui2VXMRFv8wAgO8FwMzOTheZYeVB6gq
fJ0jYkCA4CjAmCuGPieZMmNENI/Nup0W6P1bPO5xOxre787BpXQrqXZ/VpLauGqC
YX17rkpJG4w+4zFEl1Ex5K74gp+VQnrC7+WGgwd996gFRPURQL5oJC/1ofnhQedo
kdTbwPyeqK94WRhYihe3uq7B8rAsxoxPTY3oxEfN0oSuP9IEgoUZBhee9HeDMCjS
fbiL/JW/w1VjXyuufkfQbuvx122GZFCAFBej2DAGXWZKghOG7XxyPYYlam7A5eBQ
DIJ+nY4hRh9r01A0LszRA5oQXs3nhUqWymbiR2gXMGrumsC0tGB45FKX3xWKBg+a
iQ3bdfyLcLgM0c2eXgQRvX1k89D5El/byushVTWSjUgf/4UwgxfvzmvAiZm8KSGb
Jd7SSZPCQmVwNbq/RlwVt4QIMv1lHXnvklc8ZQKmdNRHo/sICl00jGCq4ahpLcul
WeRrAdvaWk/fatr0ywplIByHtvntZnLQ06GSWu+1cRP4TmLxblJrnRj2oq26QN70
yhWSKDdj61wiTWzsGel3LblgJGdr2QtmZA==
-----END CERTIFICATE-----
"

########################################################################################################################
# Functions
########################################################################################################################

log_warn() {
  local -r message="${1}"

  if [[ "${quiet}" != "1" ]]; then
    printf "%s\n" "[⚠️] ${message}" >/dev/tty
  fi
}

log_error() {
  local -r message="${1}"

  printf "%s\n" "[🛑] ${message}" >/dev/tty
}

log_ok() {
  local -r message="${1}"

  if [[ "$quiet" != "1" ]]; then
    printf "%s\n" "[✅] ${message}" >/dev/tty
  fi
}

log_info() {
  local -r message="${1}"

  if [[ "$quiet" != "1" ]]; then
    printf "%s\n" "[ℹ️] ${message}" >/dev/tty
  fi
}

handle_shift_error() {
  local -r arg_name="${1}"

  log_error "${arg_name} argument value is missing but required"
  return 1
}

assert_command_exists() {
  local -r command_name="${1}"
  local -r command_missing_details="${2}"
  if ! command -v "${command_name}" 1>/dev/null 2>&1; then
    log_error "Command '${command_name}' is missing but required${command_missing_details}"
    return 1
  fi
}

get_apple_connect_cookie() {
  local -r certmgr_host="${1}"

  # Determine Certificate Manager application ID
  local certmgr_app_id
  if [[ "${certmgr_host}" =~ "certificatemanager-gg".* ]]; then
    # Golden Gate
    certmgr_app_id="171271"
  else
    # Corporate
    certmgr_app_id="3045"
  fi

  # Obtain AppleConnect authentication cookie (acack)
  local acack
  if [[ -z "${APPLECONNECT_DAW_TOKEN}" ]]; then
    local apple_connect_response
    if ! apple_connect_response=$(appleconnect serviceTicket --realm="APPLECONNECT.APPLE.COM" \
                                                             --appId="${certmgr_app_id}" \
                                                             --dawToken \
                                                             --show-signIn-dialog \
    ); then
      log_error "AppleConnect authentication failed"
      echo "${apple_connect_response}"
      return 1
    fi
    acack="${apple_connect_response}"
  else
    acack="${APPLECONNECT_DAW_TOKEN}"
  fi

  echo "${acack}"
}

json_escape() {
  local -r input="${1}"

  if [[ -n "${input}" ]]; then
    jq --null-input --arg arg1 "${input}" '$arg1'
  else
    echo "null"
  fi
}

construct_json_object() {
  local json_object
  if [[ $# -eq 0 ]]; then
    # Empty JSON object
    json_object="{}"
  else
    # Non-empty JSON object
    json_object=""
    while [[ $# -gt 1 ]]; do
      json_object+="\"$1\": $2, "
      shift 2
    done
    json_object="{ ${json_object%, } }"
  fi
  echo -n "${json_object}"
}

construct_json_array_of_strings() {
  local json_array
  if [[ $# -eq 0 ]]; then
    # Empty JSON array
    json_array="{}"
  else
    # Non-empty JSON array
    json_array=""
    while [[ $# -gt 0 ]]; do
      json_array+="$(json_escape "$1"), "
      shift
    done
    json_array="[ ${json_array%, } ]"
  fi
  echo -n "${json_array}"
}

# inject unencrypted ra_key into secret
# inject Apple Root CA certs into secret
inject_ra_credentials_to_k8s() {
  local -r namespace="${1}"
  local -r ra_password="${2}"
  local -r ra_key="${3}"
  local -r ra_subscriber_cert="${4}"
  local -r ra_issuer_cert="${5}"

  local decrypted_ra_key
  decrypted_ra_key=$(openssl pkcs8 -in <(echo "${ra_key}") -passin pass:"${ra_password}")

  local secret_name
  secret_name="ra-credentials-"$(openssl rand -hex 5)

  if (cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: ${secret_name}
  namespace: ${namespace}
type: Opaque
data:
  ra_key: $(echo -n "${decrypted_ra_key}" | base64 | tr -d '\n')
  ra_subscriber_cert: $(echo -n "${ra_subscriber_cert}" | base64 | tr -d '\n')
  ra_issuer_cert: $(echo -n "${ra_issuer_cert}" | base64 | tr -d '\n')
  server_ca_certs: $(echo -n "${APPLE_ROOT_CAS}" | base64 | tr -d '\n')
EOF
); then
    log_ok "RA credentials are stored in secrets \"${secret_name}\" in namespace \"${namespace}\""
  else
    log_error "Cannot store RA credentials in secrets \"${secret_name}\" in namespace \"${namespace}\""
    return 1
  fi
}

main() {
  local arg
  local admin_group_dsid ra_group_dsid custom_ou description
  local certmgr_host="certificatemanager.apple.com"
  local ra_cn="RA for Apple Certificate Manager"
  local skip_private_ca private_ca_id ra_k8s_namespace
  skip_private_ca="0"
  while [[ "$#" -gt "0" ]]; do
    arg="${1}"
    case "${arg}" in
    # Help
    -\? | -h | --help)
      printf '%s\n' "${USAGE}"
      exit 0
      ;;
    # Skip PrivateCA creation
    -sp | --skip-private-ca)
      skip_private_ca="1"
      shift
      ;;
    # Admin group DSID
    -ad | --admin-group-dsid)
      admin_group_dsid="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # RA group DSID
    -ra | --ra-group-dsid)
      ra_group_dsid="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # Certificate Manager Host
    -cmh | --certmgr-host)
      certmgr_host="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # Custom OU
    -ou | --custom-ou)
      custom_ou="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # Description
    -d | --description)
      description="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # RA CN
    -cn | --ra-cn)
      ra_cn="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # Private CA ID
    -pca | --private-ca-id)
      private_ca_id="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # RA k8s Namespace
    -ns | --ra-k8s-namespace)
      ra_k8s_namespace="${2}"
      shift
      shift || handle_shift_error "${arg}"
      ;;
    # Default
    *)
      log_error "Unsupported argument: ${arg}"
      exit 1
      ;;
    esac
  done

  # Ensure mandatory arguments are provided
  if [[ "${skip_private_ca}" == "0" ]] && [[ -z "${admin_group_dsid}" ]]; then
    log_error "--admin-group-dsid argument is missing but required"
    exit 1
  fi

  if [[ -z "${ra_group_dsid}" ]]; then
    log_error "--ra-group-dsid argument is missing but required"
    exit 1
  fi

  # Ensure required dependencies exist
  if [[ -z "${APPLECONNECT_DAW_TOKEN}" ]]; then
    assert_command_exists "appleconnect" "; please install AppleConnect"
  fi
  assert_command_exists "jq" "; please install this package (macOS: 'brew install jq')"
  if [[ "${ra_k8s_namespace}" ]]; then
    assert_command_exists "kubectl" "; please install kubectl"
    # validate namespace
    if ! kubectl get ns "${ra_k8s_namespace}" &> /dev/null; then
      log_error "Please make sure namespace \"${ra_k8s_namespace}\" exists."
      return 1
    fi
  fi

  # Authenticate to Certificate Manager using AppleConnect
  log_info "Authenticating to Certificate Manager using AppleConnect"
  local apple_connect_cookie certmgr_response csrf_header app_auth_cookie
  apple_connect_cookie="acack=$(get_apple_connect_cookie "${certmgr_host}")"
  local -r curl_options_default=(
    --silent
    --show-error
  )
  if ! certmgr_response=$(curl "${curl_options_default[@]}" \
                          --silent \
                          --head \
                          --request "POST" \
                          --header "Origin: https://${certmgr_host}" \
                          --cookie "${apple_connect_cookie}" \
                          "https://${certmgr_host}/api/v1/cert-mgmt/certs"
  ); then
    log_error "Failed to connect to Certificate Manager"
    return 1
  fi
  if ! app_auth_cookie=$(grep "Set-Cookie: " <<< "${certmgr_response}" | sed 's|Set-Cookie: \([^;]*\).*|\1|'); then
    log_error "Failed to obtain Certificate Manager application cookie"
    echo "${certmgr_response}"
    return 1
  fi
  if ! csrf_header=$(grep "X-Csrf-Token: " <<< "${certmgr_response}" | tr -d "\r"); then
    log_error "Failed to obtain Certificate Manager CSRF token"
    echo "${certmgr_response}"
    return 1
  fi
  local -r curl_options_cm_ac_auth=(
    "${curl_options_default[@]}"
    --header "Origin: https://${certmgr_host}"
    --header "${csrf_header}"
    --cookie "${app_auth_cookie};${apple_connect_cookie}"
  )

  # Issue RA Credential from Certificate Manager
  log_info "Issuing RA credential from Certificate Manager"
  local ra_password openssl_response ra_key ra_csr ra_subscriber_cert ra_issuer_cert
  ra_password=$(openssl rand -base64 32)
  openssl_response=$(openssl req -new \
                                 -newkey rsa:2048 \
                                 -sha256 \
                                 -passout "pass:${ra_password}" \
                                 -keyout >(cat -) \
                                 -subj "/" \
                                 2>&1)
  ra_key=$(sed -n '/^-----BEGIN ENCRYPTED PRIVATE KEY-----$/,/^-----END ENCRYPTED PRIVATE KEY-----$/p' \
    <<< "${openssl_response}")
  ra_csr=$(sed -n '/^-----BEGIN CERTIFICATE REQUEST-----$/,/^-----END CERTIFICATE REQUEST-----$/p' \
    <<< "${openssl_response}")
  local additional_inputs_components=("commonName" "$(json_escape "${ra_cn}")")
  local sans_components=("iPAddress" "$(construct_json_array_of_strings "0.0.0.0")")
  local -r certmgr_request="$(cat << EOF
{
  "certTypeId": "tls_client_internal",
  "managementGroupDsid": $(json_escape "${ra_group_dsid}"),
  "identityGroupDsid": $(json_escape "${ra_group_dsid}"),
  "additionalInputs": $(construct_json_object "${additional_inputs_components[@]}"),
  "sans": $(construct_json_object "${sans_components[@]}"),
  "pemCsr": $(json_escape "${ra_csr}")
}
EOF
)"
  certmgr_response=$(curl "${curl_options_cm_ac_auth[@]}" \
                          --silent \
                          --request "POST" \
                          --header "Content-Type: application/json" \
                          --data "${certmgr_request}" \
                          "https://${certmgr_host}/api/v1/cert-mgmt/certs")
  ra_subscriber_cert=$(jq --raw-output '.certChain[0] | select (.!=null)' <<< "${certmgr_response}")
  ra_issuer_cert=$(jq --raw-output '.certChain[1] | select (.!=null)' <<< "${certmgr_response}")
  if [[ -z "${ra_subscriber_cert}" ]] || [[ -z "${ra_issuer_cert}" ]]; then
    log_error "Failed to issue RA credential from Certificate Manager"
    jq <<< "${certmgr_response}"
    return 1
  fi

  if [[ "${skip_private_ca}" == "1" ]]; then
    log_info "Skip Private CA creation"
  else
    local status_code
    if [[ "${private_ca_id}" ]]; then
      # Validate private_ca_id if presented
      status_code=$(curl "${curl_options_cm_ac_auth[@]}" \
                          --silent \
                         --output /dev/null \
                         --write-out "%{http_code}"  \
                          --request "GET" \
                          "https://${certmgr_host}/api/v1/private-ca/${private_ca_id}")
      if [[ "$status_code" -ne 200 ]]; then
        log_error "Private CA ${private_ca_id} not found in Certificate Manager"
        return 1
      fi
    else
      # Creating Private CA if not presented
      log_info "Creating Private CA in Certificate Manager"
      certmgr_response=$(curl "${curl_options_cm_ac_auth[@]}" \
                              --silent \
                              --request "POST" \
                              --header "Content-Type: application/json" \
                              --data "\
{\
  \"customOu\": $(json_escape "${custom_ou}"),\
  \"description\": $(json_escape "${description}"),\
  \"adminUid\": \"idms.group.${admin_group_dsid}\",\
  \"raUid\": \"idms.group.${ra_group_dsid}\"\
}"\
                          "https://${certmgr_host}/api/v1/private-ca")
      private_ca_id=$(jq --raw-output '.privateCaId | select (.!=null)' <<< "${certmgr_response}")
      if [[ -z "${private_ca_id}" ]]; then
        log_error "Failed while creating Private CA in Certificate Manager"
        jq <<< "${certmgr_response}"
        return 1
      fi
    fi
    log_ok "Private CA ID: ${private_ca_id}"
  fi

  if [[ "${ra_k8s_namespace}" ]]; then
    inject_ra_credentials_to_k8s "${ra_k8s_namespace}" \
      "${ra_password}" "${ra_key}" "${ra_subscriber_cert}" "${ra_issuer_cert}"
  else
    # print out credentials
    echo "RA Password: ${ra_password}"
    printf 'RA Credential:\n%s\n%s\n%s\n' "${ra_key}" "${ra_subscriber_cert}" "${ra_issuer_cert}"
  fi
}

########################################################################################################################
# Main
########################################################################################################################

main "$@"
