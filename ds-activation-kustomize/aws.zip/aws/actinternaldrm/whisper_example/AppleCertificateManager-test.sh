export CMCS_K8S_CLIENT_CERT_SECRET_NAME="ra-credentials-913c2cd538"   # e.g., ra-credentials-f873c8faf7
export CMCS_K8S_CLIENT_CERT_SECRET_NAMESPACE="cmcs-k8s-operator-system"      # e.g., cmcs-k8s-operator-system
export CMCS_K8S_APP_IDENTITY_GROUP_DSID="7844835"      # e.g., 5509286
export CMCS_K8S_APP_MANAGEMENT_GROUP_DSID="7844833"     # e.g., 5509285

cat <<EOF | kubectl apply -f -
apiVersion: cmcs.crypto-services.apple.com/v1
kind: AppleCertificateManager
metadata:
  name: applecm-whisper-corpca
spec:
  baseURL: https://certificatemanager.apple.com:9000
  clientCertSecretName: "${CMCS_K8S_CLIENT_CERT_SECRET_NAME}"
  clientCertSecretNamespace: "${CMCS_K8S_CLIENT_CERT_SECRET_NAMESPACE}"
  corpCa:
    apiVersion: v1
    identityGroupDsid: "${CMCS_K8S_APP_IDENTITY_GROUP_DSID}"
    managementGroupDsid: "${CMCS_K8S_APP_MANAGEMENT_GROUP_DSID}"
EOF

