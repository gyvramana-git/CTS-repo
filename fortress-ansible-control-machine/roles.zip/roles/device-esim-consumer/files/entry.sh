#!/bin/bash
set -e

APP=$2
PORT=$3
ENV=$4
PROFILE=$5
CONFIG=$6

APP_LOWERCASE=$(echo "$APP" | tr '[:upper:]' '[:lower:]')


#java -Xmx16384m -Xms16384m -Dapp-config.module=M02563 -Dapp.name=ESCustomer -Dapp-config.env=UAT -Dapp-config.profile=QA1 -Dprivate.file=/apps/etc/private/non-prod.properties -Dspring.profiles.active=QA1 -Dcatalina.base=/home/esim/app/escustomer/  -Dprivate.path=/apps/etc/private -jar /home/esim/app/escustomer.jar

java -Dapp-config.module=M03085 -Dspring.profiles.active=non-prod -Dapp-config.app-id=182270 -Dapp-config.env=$ENV -Dapp-config.profile=$PROFILE -Dreactor.netty.http.server.accessLogEnabled=true -Dapp.name=$APP_LOWERCASE -Dprivate.file=/opt/apps/etc/private/A3_135275.properties -cp @/app/jib-classpath-file com.apple.ds.device.esim.consumer.DeviceEsimConsumerApplication
