#!/bin/bash
set -e

sleep 2

# Getting properties
echo "!!! Dowloading properties just a second..... !!!"

APP=$2
PORT=$3
ENV=$4

if [[ $ENV == "PRODUCTION-NC1" ]]; then
  memcached.hosts=100.84.3.132:11221, 100.84.3.132:11222, 100.84.3.132:11223, 100.84.3.132:11224, 100.84.3.133:11221, 100.84.3.133:11222, 100.84.3.133:11223, 100.84.3.133:11224, 100.84.3.134:11221, 100.84.3.134:11222, 100.84.3.134:11223, 100.84.3.134:11224, 100.84.3.135:11221, 100.84.3.135:11222, 100.84.3.135:11223, 100.84.3.135:11224
  sed -i "s/^memcached\.hosts=.*/memcached.hosts=$MEM_HOST/" /apps/etc/private/$APP.properties
elif [[ $ENV == "PRODUCTION-NC2" ]]; then
  memcached.hosts=100.84.3.132:11221, 100.84.3.132:11222, 100.84.3.132:11223, 100.84.3.132:11224, 100.84.3.133:11221, 100.84.3.133:11222, 100.84.3.133:11223, 100.84.3.133:11224, 100.84.3.134:11221, 100.84.3.134:11222, 100.84.3.134:11223, 100.84.3.134:11224, 100.84.3.135:11221, 100.84.3.135:11222, 100.84.3.135:11223, 100.84.3.135:11224
  sed -i "s/^memcached\.hosts=.*/memcached.hosts=$MEM_HOST/" /apps/etc/private/$APP.properties
elif [[ $ENV == "PRODUCTION-RN1" ]]; then
  memcached.hosts=10.180.240.144:11221, 10.180.240.144:11222, 10.180.240.144:11223, 10.180.240.144:11224, 10.180.240.145:11221, 10.180.240.145:11222, 10.180.240.145:11223, 10.180.240.145:11224, 10.180.240.146:11221, 10.180.240.146:11222, 10.180.240.146:11223, 10.180.240.146:11224, 10.180.240.147:11221, 10.180.240.147:11222, 10.180.240.147:11223, 10.180.240.147:11224
  sed -i "s/^memcached\.hosts=.*/memcached.hosts=$MEM_HOST/" /apps/etc/private/$APP.properties
elif [[ $ENV == "PRODUCTION-RN2" ]]; then
  memcached.hosts=10.180.240.144:11221, 10.180.240.144:11222, 10.180.240.144:11223, 10.180.240.144:11224, 10.180.240.145:11221, 10.180.240.145:11222, 10.180.240.145:11223, 10.180.240.145:11224, 10.180.240.146:11221, 10.180.240.146:11222, 10.180.240.146:11223, 10.180.240.146:11224, 10.180.240.147:11221, 10.180.240.147:11222, 10.180.240.147:11223, 10.180.240.147:11224
  sed -i "s/^memcached\.hosts=.*/memcached.hosts=$MEM_HOST/" /apps/etc/private/$APP.properties
fi

deploy() {


cd /ngs/app/pesdkr/bin/

echo $pwd

./startup.sh start $APP $PORT $ENV

}


start() {

cd /ngs/app/pesdkr/bin/

echo $pwd

./startup.sh start $APP $PORT $ENV

}


restart() {

cd /ngs/app/pesdkr/bin/

echo $pwd

./startup.sh restart $APP $PORT $ENV

}


###################################
# Main Script Logic Starts Here   #
###################################

case "$1" in

 deploy)
       deploy
       ;;
 start)
       start
       ;;
 restart)
       restart
       ;;


 *)
       echo $"Usage: $prog {deploy|start|restart}"
       exit 1
esac
