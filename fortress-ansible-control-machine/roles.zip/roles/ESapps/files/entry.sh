#!/bin/bash
set -e

APP=$2
PORT=$3
ENV=$4
CONFIG=$5

APP_LOWERCASE=$(echo "$APP" | tr '[:upper:]' '[:lower:]')

deploy() {

mkdir -p ~/.jkrypt
cp /home/esim/app/certs/config ~/.jkrypt/config
cd /home/esim/app

jkrypt decrypt -k dvsr-artifact-encryption -f /home/esim/app/$APP_LOWERCASE.jar.tar.gz

if [[ $(cat /apps/etc/private/java_opts.txt | grep -c "$APP") > 0 ]]; then
echo "Application available in java_opts.txt file"
java_opts="$(grep -w $APP /apps/etc/private/java_opts.txt | awk '{ for(i=3; i<=NF; ++i) printf $i""FS; print "" }')"
else
java_opts="-Dcatalina.base=/home/esim/app/$APP_LOWERCASE/ -Dprivate.path=/apps/etc/private -Dkeystone.env=$ENV -Dlog4j.configurationFile=$CONFIG"
fi

#java -Xmx16384m -Xms16384m -Dapp-config.module=M02563 -Dapp.name=ESCustomer -Dapp-config.env=UAT -Dapp-config.profile=QA1 -Dprivate.file=/apps/etc/private/non-prod.properties -Dspring.profiles.active=QA1 -jar /home/esim/app/escustomer.jar

#java $java_opts -jar /home/esim/app/$APP_LOWERCASE.jar


#java -Xmx16384m -Xms16384m -Dapp-config.module=M02563 -Dapp.name=ESCustomer -Dapp-config.env=UAT -Dapp-config.profile=QA1 -Dprivate.file=/apps/etc/private/non-prod.properties -Dspring.profiles.active=QA1 -Dcatalina.base=/home/esim/app/escustomer/  -Dprivate.path=/apps/etc/private -jar /home/esim/app/escustomer.jar

java -Xmx16384m -Xms16384m  -Dapp.name=$APP -Dspring.profiles.active=$ENV -Dcatalina.base=/home/esim/app/$APP_LOWERCASE/ -Dlog4j.configurationFile=$CONFIG -Dprivate.path=/apps/etc/private -jar /home/esim/app/$APP_LOWERCASE.jar

#while :; do echo "."; sleep 5 ; done

}
###################################
# Main Script Logic Starts Here   #
###################################

case "$1" in

  deploy)
        deploy
        ;;
  start)
        start
        ;;
  restart)
        restart
        ;;


  *)
        echo $"Usage: $prog {deploy|start|restart}"
        exit 1

esac
