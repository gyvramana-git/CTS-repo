#!/bin/bash
# WARNING:

APP_NAME=$2
ENV_NAME=$4
USER='pesdkr'
HOST_IP=`hostname -i`
HOST_NAME=`hostname`
export KEYSTONE_APP_NAME=$APP_NAME
export CATALINA_HOME="/ngs/app/$USER/tools/tomcat"
export CATALINA_BASE="/apps/${APP_NAME}/Current/${APP_NAME}Home"
export CATALINA_PID="/var/tmp/${APP_NAME}.pid"
export CATALINA_TMPDIR="/ngs/app/$USER/tmp/${APP_NAME}"
export CATALINA_OUT="/apps/${APP_NAME}/Current/${APP_NAME}Home/logs/$HOST_NAME.catalina.out"
#CurrentJDK -> /ngs/app/pesdkr/tools/applejdk-11.0.4.11.1-linux-x64
export JAVA_HOME="/ngs/app/$USER/tools/CurrentJDK"


echo "$ENV_NAME" > /apps/etc/environment.config

if [ ${ENV_NAME} == NCIT2 ]
then
cp "/apps/etc/private/NCIT2.properties" "$CATALINA_BASE/conf/NCIT2.properties"
fi

#java_opts="$(grep -w $APP_NAME /apps/etc/private/java_opts.txt | awk '{ for(i=3; i<=NF; ++i) printf $i""FS; print "" }')"
if [ ${APP_NAME} == CDSEmailSettingsService ]
then
  java_opts=
else
  java_opts="$(grep -w $APP_NAME /apps/etc/private/java_opts.txt | awk '{ for(i=3; i<=NF; ++i) printf $i""FS; print "" }')"
fi
export CATALINA_OPTS="-Dhostname=${HOST_NAME} -server -Djava.net.preferIPv4Stack=true -Dkeystone.properties=/apps/etc/keystone.properties -Djava.awt.headless=true -XX:+HeapDumpOnOutOfMemoryError -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:G1ReservePercent=10 -XX:ParallelGCThreads=8 -XX:ConcGCThreads=2 $java_opts -XX:+OptimizeStringConcat -Xnoclassgc -Dfile.encoding=UTF-8 -Duser.timezone=GMT -XX:HeapDumpPath=/apps/${APP_NAME}/Current/${APP_NAME}Home/logs/${HOST_NAME}-${APP_NAME}-${PORT}-heap.log"
find /ngs/app/$USER/tmp/${APP_NAME}/ -type f -exec rm -rf {} \; 2> /dev/null

[[ ! -d $CATALINA_TMPDIR ]] && mkdir $CATALINA_TMPDIR

getpid() {
          TCPID=`pgrep -u $USER -f "/(.*\bjava\b.*)(:?=.*${CATALINA_BASE}.*)/"`
}

start() {
        echo "Starting Tomcat: "
        echo "Using CATALINA_OPTS:  $CATALINA_OPTS"
        $CATALINA_HOME/bin/startup.sh
        if [ $? -eq 0 ]; then
          sleep 5
          getpid
          echo "New ${APP_NAME} PID: $TCPID"
          tail -f /dev/null
        else
          echo "Issues with ${APP_NAME} startup --- ABORTING START!!!!"
          exit 2
        fi

        exit
}

stop() {
        echo "Stopping Tomcat: "
        getpid
        echo "Old ${APP_NAME} PID: $TCPID"
        $CATALINA_HOME/bin/shutdown.sh
        sleep 5
        for i in {1..3}; do
          if getpid; then
            echo "${APP_NAME} still running with PID: $TCPID --- Wait for 10s before checking status again.."
            sleep 10
            echo "${APP_NAME} still running with PID: $TCPID --- Going ahead with pkill "
            pkill -u $USER -f '/(.*\bjava\b.*)(:?=.*\b${APP_NAME}Home\b.*)(:?=.*\btomcat\b.*)/'
            sleep 2
          else
            echo "${APP_NAME} shutdown gracefully"
            break
          fi
        done
        if getpid; then
          echo "${APP_NAME} still running with PID: $TCPID after a total wait time of 65secs ---"
          echo "Taking ThreadDump before Force terminating the process ---"
          kill -QUIT `echo $TCPID` > /apps/${APP_NAME}/Current/${APP_NAME}Home/logs/${HOST_NAME}.thraeddump 2>&1
          if [ $? -eq 0 ]; then
            echo "ThreadDump can be found at /apps/${APP_NAME}/Current/${APP_NAME}Home/logs/${HOST_NAME}.thraeddump"
          fi
          kill -9 `echo $TCPID`
        fi
}

### See how we were called.
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart)
        stop
        start
        ;;
  *)
        echo $"Usage: $prog {start|stop|restart}"
        exit 1
esac
