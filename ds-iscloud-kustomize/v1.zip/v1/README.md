# v1

Changed:
- AppConfig Init Container is now running in A3 instead of x509
- CSI and CMCS Operator dependencies
- Log Rotation is now cronjob instead of sidecar
- Optimized our resource requests
