#!/bin/bash
set -e

# Getting properties
echo "!!! Dowloading properties just a second..... !!!"

APP=$2
PORT=$3
ENV=$4
CONFIG=$5

echo "APP:$2 ,PORT:$3 , ENV:$4 , CONFIG:$5"

APP_LOWERCASE=$(echo "$APP" | tr '[:upper:]' '[:lower:]')

deploy() {




cd /apps/etc


if [[ $(cat /apps/etc/private/java_opts.txt | grep -c "$APP") > 0 ]]; then
echo "Application available in java_opts.txt file"
java_opts="$(grep -w $APP /apps/etc/private/java_opts.txt | awk '{ for(i=3; i<=NF; ++i) printf $i""FS; print "" }')"
else
java_opts="-Dcatalina.base=/ngs/app/pesdkr/${APP_LOWERCASE}/ -Dprivate.path=/apps/etc/private -Dkeystone.env=${ENV} -Dlog4j.configurationFile=${CONFIG}  -Dfile.encoding=UTF-8"
fi

echo "Trying to start application with : $java_opts"
/ngs/app/pesdkr/tools/applejdk-17.0.3.7.3/bin/java $java_opts -jar /ngs/app/pesdkr/$APP_LOWERCASE.jar
}


start() {

cd /ngs/app/pesdkr/bin/

echo $pwd

/ngs/app/pesdkr/tools/applejdk-17.0.3.7.3/bin/java $java_opts -jar /ngs/app/pesdkr/$APP_LOWERCASE.jar

}


restart() {

cd /ngs/app/pesdkr/bin/

echo $pwd

/ngs/app/pesdkr/tools/applejdk-17.0.3.7.3/bin/java $java_opts -jar /ngs/app/pesdkr/$APP_LOWERCASE.jar

}


###################################
# Main Script Logic Starts Here   #
###################################

case "$1" in

  deploy)
        deploy
        ;;
  start)
        start
        ;;
  restart)
        restart
        ;;


  *)
        echo $"Usage: $prog {deploy|start|restart}"
        exit 1
esac
