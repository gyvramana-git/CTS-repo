#!/bin/bash
set -e

# Getting properties
echo "!!! Dowloading properties just a second..... !!!"

APP=$2
PORT=$3
ENV=$4

if [ ${PORT} == 34095 ]
then
sed -i 's/34092/34095/g' /apps/etc/private/FondueHTTPsConnector.txt
fi

chmod 600 /apps/etc/private/*.key | echo "Changing permissions for key files and ignoreing error if key files not found"

deploy() {

cd /ngs/app/pesdkr/bin

echo $pwd

./startup.sh start $APP $PORT $ENV

}

start() {


cd /ngs/app/pesdkr/bin/

echo $pwd

./startup.sh start $APP $PORT $ENV

}


restart() {

cd /ngs/app/pesdkr/bin/

echo $pwd

./startup.sh restart $APP $PORT $ENV

}


###################################
# Main Script Logic Starts Here   #
###################################

case "$1" in

  deploy)
        deploy
        ;;
  start)
        start
        ;;
  restart)
        restart
        ;;


  *)
        echo $"Usage: $prog {deploy|start|restart}"
        exit 1
esac
