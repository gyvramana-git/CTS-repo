#!/bin/bash
mv /ngs/app/pesdkr/private/memcached-sasl.db.conf /ngs/app/pesdkr/private/memcached-sasl.db
cd /ngs/app/pesdkr
source /ngs/app/pesdkr/.bashrc

/ngs/app/pesdkr/saslmemcached_controller --action start

tail -f /dev/null
