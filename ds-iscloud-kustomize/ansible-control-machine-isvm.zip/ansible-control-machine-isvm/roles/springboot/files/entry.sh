#!/bin/bash
set -e

# Getting properties
echo "!!! Dowloading properties just a second..... !!!"

APP=$2
PORT=$3
ENV=$4
PROP_REPO=$5
CONFIG=$6

APP_LOWERCASE=$(echo "$APP" | tr '[:upper:]' '[:lower:]')

deploy() {

token=$(grep 'token :' /apps/etc/secrets/keys.txt | awk '{print $NF}')


vault_pass=$(grep 'vault_pass :' /apps/etc/secrets/keys.txt | awk '{print $NF}')



cd /apps/etc

git config --global http.sslCAInfo /ngs/app/pesdkr/aca.pem

git clone --branch "$ENV" https://"$token"@github.pie.apple.com/conduit/$PROP_REPO.git

cp /apps/etc/$PROP_REPO/$ENV/$APP* /apps/etc/private/


cp -rf /apps/etc/$PROP_REPO/$ENV/keystores/* /apps/etc/private/

echo $vault_pass >~/.secrets

#echo !!! Enter Ansible Vault by which Properties encrypted !!!
ansible-vault decrypt /apps/etc/private/"$APP".properties  --vault-password-file=~/.secrets

ansible-vault decrypt /apps/etc/private/"$APP"HTTPsConnector.txt  --vault-password-file=~/.secrets

ansible-vault decrypt /apps/etc/private/*.pem  --vault-password-file=~/.secrets

ansible-vault decrypt /apps/etc/private/*.key  --vault-password-file=~/.secrets

ansible-vault decrypt /apps/etc/private/software-auth.yaml  --vault-password-file=~/.secrets

echo "ansible-vault work completed"

#rm ~/.secrets

#rm -rf /apps/etc/$PROP_REPO

echo "Trying to start application"
/ngs/app/pesdkr/tools/applejdk-11.0.4.11.1-linux-x64/bin/java -Dcatalina.base=/ngs/app/pesdkr/$APP_LOWERCASE/ -Dprivate.path=/apps/etc/private -Dkeystone.env=$ENV -Dlog4j.configurationFile=$CONFIG  -Dfile.encoding=UTF-8  -jar /ngs/app/pesdkr/$APP_LOWERCASE.jar
}


start() {

cd /ngs/app/pesdkr/bin/

echo $pwd

/ngs/app/pesdkr/tools/applejdk-11.0.4.11.1-linux-x64/bin/java -Dcatalina.base=/ngs/app/pesdkr/$APP_LOWERCASE/ -Dprivate.path=/apps/etc/private -Dkeystone.env=$ENV -Dlog4j.configurationFile=$CONFIG  -Dfile.encoding=UTF-8 -jar /ngs/app/pesdkr/$APP_LOWERCASE.jar

}


restart() {

cd /ngs/app/pesdkr/bin/

echo $pwd

/ngs/app/pesdkr/tools/applejdk-11.0.4.11.1-linux-x64/bin/java -Dcatalina.base=/ngs/app/pesdkr/$APP_LOWERCASE/ -Dprivate.path=/apps/etc/private -Dkeystone.env=$ENV -Dlog4j.configurationFile=$CONFIG  -Dfile.encoding=UTF-8  -jar /ngs/app/pesdkr/$APP_LOWERCASE.jar

}


###################################
# Main Script Logic Starts Here   #
###################################

case "$1" in

  deploy)
        deploy
        ;;
  start)
        start
        ;;
  restart)
        restart
        ;;


  *)
        echo $"Usage: $prog {deploy|start|restart}"
        exit 1
esac
