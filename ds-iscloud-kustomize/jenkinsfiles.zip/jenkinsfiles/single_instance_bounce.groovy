properties([gitLabConnection(''), parameters([choice(choices: ['ma-dst-lapp20.corp.apple.com','ma-dst-lapp29.corp.apple.com','ma-dst-lapp22.corp.apple.com','ma-dst-lapp23.corp.apple.com','ma-dst-lapp24.corp.apple.com','ma-dst-lapp25.corp.apple.com','ma-dst-lapp26.corp.apple.com','ma-dst-lapp27.corp.apple.com','ma-dst-lapp28.corp.apple.com','ma-dst-lapp29.corp.apple.com','ma-dst-lapp34.corp.apple.com','ma-dst-lapp35.corp.apple.com','ma-dst-lapp36.corp.apple.com','ma-dst-lapp39.corp.apple.com','ma1-dst-lapp01.corp.apple.com','ma1-dst-lapp02.corp.apple.com','ma1-dst-lapp03.corp.apple.com','ma1-dst-lapp04.corp.apple.com','ma1-dst-lapp11.corp.apple.com','ma1-dst-lapp12.corp.apple.com'], description: 'Please Enter the Host Name', name: 'HOST'), [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: 'Choose the Applications', filterLength: 1, filterable: false, name: 'Application', randomName: 'choice-parameter-9657454582631237', referencedParameters: 'HOST', script: [$class: 'GroovyScript', fallbackScript: [classpath: [], sandbox: false, script: 'return[\'Failed Application Input\']'], script: [classpath: [], sandbox: false, script: '''def command = ["/bin/bash" , "-c" , "sh /ngs/app/dsat/jenkins/jenkins_bounce.sh ${HOST} dst"]

def proc = command.execute()
proc.waitFor()

def output = proc.in.text

return output.tokenize()''']]], choice(choices: ['restart', 'stop', 'start'], description: '', name: 'ACTION'), booleanParam(name: 'EnableDebug', defaultValue: false, description: 'Enable ansible debug logs'), choice(choices: ['1', '2', '3', '4'], description: 'Level of verbosity if Debug Logs are enabled (i.e. EnableDebug is true).', name: 'VerbosityLevel')])])

pipeline{
    // environment {
    // BUILD_USER = "BUILD_USER"

    // }

    agent { label 'master' }

stages{
    // stage('Validate parameters') {
    //         steps{
    //             script{
    //             if ("$HOST" == '' ||  "$Application" == '' || "$cr_number" == ''  ||  "$ACTION" == '' ){

    //                 echo " Invalid Parameters Please Validate"
    //                 currentBuild.result = 'FAILURE'
    //                 error("Build failed because of this and that..")
    //             }
    //             else{
    //                  echo " Parameters Looks good "
    //             }
    //             }

    //         }

    //     }

    stage('Bouncing Application') {
        steps{
            withCredentials([usernamePassword(credentialsId: 'nitroapi', usernameVariable: 'nitro_user', passwordVariable: 'nitro_pass'), usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'vault_token', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')]) {
            sh '''
            set +x
                app_name=$(echo $Application | awk -F- '{print $1}')
            set -x
                echo Selected Application=$app_name
            set +x
                mv /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts_old
                sed '2d' /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts_old >> //ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts
                rm -rf /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts_old
                echo "${HOST}" >> /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts
                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                    ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/bounce.yml -u dst -e Application=${Application} -e traffic=${traffic} -e app_name=$app_name -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e grp=1 -e pod="patching" -e token="${token_pass}" -e vault_pass="${vault_password}" -e memcached_password="${memcached_password}" -e ticket_id="CHG000147938" -e Environment=QA --limit QA_1 -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts -e action=$ACTION
                else
                    echo "Running without debug logs"
                    /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/bounce.yml -u dst -e Application=${Application} -e traffic=${traffic} -e app_name=$app_name -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e grp=1 -e pod="patching" -e token="${token_pass}" -e vault_pass="${vault_password}" -e memcached_password="${memcached_password}" -e ticket_id="CHG000147938" -e Environment=QA --limit QA_1 -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts -e action=$ACTION
                fi
                mv /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts_old
                sed '2d' /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts_old >> /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts
                rm -rf /ngs/app/dsat/jenkins/ansible-control-machine/environments/patching/QA/hosts/hosts_old
            set -x
         '''
             }
        }
    }
    stage('Remove Vault Creds')
        {
            steps {
                withCredentials([usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'vault_token', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')])
                {
                sh '''
                    set +x
                    sed -i -e "s/${token_pass}/git_token/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                    sed -i -e "s/${vault_password}/ansible_vault/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                    sed -i -e "s/${memcached_password}/memcached_port/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                    set -x
                '''
                echo "Removed Vault Credentials"
                }
            }
        }
}
    // post {
    //     failure {
    //         emailext body:
    //         '''
    //          <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    //           <html>
    //           <head><title></title>
    //           <style>
    //           table {
    //             font-family: arial, sans-serif;
    //             border-collapse: collapse;
    //             width: 100%;
    //           }

    //           td, th {
    //             border: 1px solid #dddddd;
    //             text-align: left;
    //             padding: 8px;
    //           }

    //           tr:nth-child(even) {
    //             background-color: #dddddd;
    //           }
    //           </style>
    //           </head>
    //           <body>
    //           </table>
    //           <table border="2" cellpadding="0" cellspacing="0"  width="900" height="100"  bgcolor="#424242">
    //             <tr >
    //               <th text="white" align="left"><H1 style="color:white;" align="center" > Deployment Notification</H1> </th>
    //             </tr>
    //           </table>
    //           <table border="1" width="900" height="100" >
    //              <tr>
    //               <td text="white" align="left"><p><h3  style="color:red">The deploy action is Failed.</h3>
    //               <table>
    //               <tr>
    //               <th>Job</th>
    //               <th>$PROJECT_NAME</th>
    //               </tr>
    //               <tr>
    //               <th>Compose File</th>
    //               <th>$Application</th>
    //               </tr>
    //               <tr>
    //               <th>Host</th>
    //               <th>$HOST</th>
    //               </tr>
    //               </table>
    //           </td>
    //           </tr>
    //           </table>
    //           <table border="1" width="900" height="100" >
    //               <tr>
    //                  <td text="white" align="left"><p><h3>Heath check status for DS Applications</h3>
    //                  <b style="color:red">Unhealthy
    //                  </td>
    //               </tr>
    //           </table>
    //           '''  ,
    //                 to: "naren_ambati@apple.com",
    //                 mimeType: 'text/html',
    //                 subject: '${DEFAULT_SUBJECT}',
    //                 replyTo: '$DEFAULT_REPLYTO'
    //     }
    //     success {
    //         emailext body:
    //         '''
    //                 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    //           <html>
    //           <head><title></title>
    //           <style>
    //           table {
    //             font-family: arial, sans-serif;
    //             border-collapse: collapse;
    //             width: 100%;
    //           }

    //           td, th {
    //             border: 1px solid #dddddd;
    //             text-align: left;
    //             padding: 8px;
    //           }

    //           tr:nth-child(even) {
    //             background-color: #dddddd;
    //           }
    //           </style>
    //           </head>
    //           <body>
    //           </table>
    //           <table border="2" cellpadding="0" cellspacing="0"  width="900" height="100"  bgcolor="#424242">
    //             <tr >
    //               <th text="white" align="left"><H1 style="color:white;" align="center" > Deployment Notification</H1> </th>
    //             </tr>
    //           </table>
    //           <table border="1" width="900" height="100" >
    //              <tr>
    //               <td text="red" align="left"><p><h3  style="color:green">The deploy action has been completed successfully.</h3>
    //               <table>
    //               <tr>
    //               <th>Triggered User</th>
    //               <th>$BUILD_USER</th>
    //               </tr>
    //               <tr>
    //               <th>Job</th>
    //               <th>$PROJECT_NAME</th>
    //               </tr>
    //               <tr>
    //               <th>Compose File</th>
    //               <th>$Application</th>
    //               </tr>
    //               <tr>
    //               <th>Host</th>
    //               <th>$HOST</th>
    //               </tr>
    //               </table>
    //           </td>
    //           </tr>
    //           </table>
    //           <table border="1" width="900" height="100" >
    //               <tr>
    //                  <td text="white" align="left"><p><h4>Heath check status for DS Applications</h4>
    //                  <b style="color:green">200 - Healthy
    //                  </td>
    //               </tr>
    //           </table>
    //   ''',
    //                 to: "naren_ambati@apple.com",
    //                 mimeType: 'text/html',
    //                 subject: '${DEFAULT_SUBJECT}',
    //                 replyTo: '$DEFAULT_REPLYTO'
    //     }
    // }
}
