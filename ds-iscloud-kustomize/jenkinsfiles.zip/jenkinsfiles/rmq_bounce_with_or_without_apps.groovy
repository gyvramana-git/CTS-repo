properties([gitLabConnection(''), parameters([[$class: 'ChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: 'Choose the environment', filterLength: 1, filterable: false, name: 'Env', randomName: 'choice-parameter-17211714514900552', script: [$class: 'GroovyScript', fallbackScript: [classpath: [], sandbox: false, script: 'return[\'error\']'], script: [classpath: [], sandbox: false, script: '''return[
\'IT\',
\'UAT\',
\'MAINT\',
\'QA4\',
\'QA5\',
\'Test\',
]''']]], [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: 'Verify the rabbitmq HOST', filterLength: 1, filterable: false, name: 'HOST', randomName: 'choice-parameter-17211714516722928', referencedParameters: 'Env', script: [$class: 'GroovyScript', fallbackScript: [classpath: [], sandbox: false, script: 'return[\'error\']'], script: [classpath: [], sandbox: false, script: '''if(Env.equals("IT")){
  return ["ma-dst-lapp26.corp.apple.com"]
}else if (Env.equals("UAT")){
  return ["ma1-dst-lapp11.corp.apple.com"]
}else if (Env.equals("MAINT")){
  return ["ma1-dst-lapp12.corp.apple.com"]
}else if (Env.equals("QA4")){
  return ["ma-dst-lapp21.corp.apple.com"]
}else if (Env.equals("QA5")){
  return ["ma-dst-lapp22.corp.apple.com"]
}else if (Env.equals("Test")){
  return ["ma1-dst-lapp13.corp.apple.com"]
}
else {
return["Unknown Env"]
}''']]], choice(choices: ['withoutapps', 'withapps'], description: 'Choose the Action', name: 'ACTION')])])

pipeline{
  agent { label 'master' }
  stages {
         stage('Validate parameters') {
            steps{
                script{
                if ("$Env" == '' || "$HOST" == '' || "$ACTION" == ''){
                    echo " Invalid Parameters Please Validate"
                    currentBuild.result = 'FAILURE'
                    error("Build failed please validate parameters.....")
                }
                else{
                     echo " Parameters Looks good "
                    }
              }
          }
     }
       stage('rabbitmq action') {
           steps {
             withCredentials([file(credentialsId: 'keys.txt', variable: 'KEYS'), usernamePassword(credentialsId: 'e208b2b4-1ad9-4e73-bcb6-e8d610bf83a8', passwordVariable: 'RMQpassword', usernameVariable: 'admin')]) {
sh '''set +x
set +e
MY_FILE_DATA=`cat $KEYS`

if [ $ACTION == "withoutapps" ]
then

ssh -t dst@${HOST} << EOF
date
echo $HOST
echo "$MY_FILE_DATA" > "/ngs/app/dst/secrets/keys.txt"
sh /ngs/app/dst/scripts/rabbitmq-bounce-only.sh
EOF

else

ssh -t dst@${HOST} << EOF
date
echo $HOST
echo "$MY_FILE_DATA" > "/ngs/app/dst/secrets/keys.txt"
sh /ngs/app/dst/scripts/rabbitmq_bounce.sh
EOF
fi'''

}
}
}
}

post {
        failure {
            emailext body:
            '''
             <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
              <html>
              <head><title></title>
              <style>
              table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 100%;
              }

              td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
              }

              tr:nth-child(even) {
                background-color: #dddddd;
              }
              </style>
              </head>
              <body>
               </table>
               <table border="2" cellpadding="0" cellspacing="0"  width="900" height="100"  bgcolor="#424242">
                <tr >
                   <th text="white" align="left"><H1 style="color:white;" align="center" > RMQ-Bounce with or without apps Job Notification</H1> </th>
                </tr>
               </table>
               <table border="1" width="900" height="100" >
                 <tr>
                   <td text="white" align="left"><p><h3  style="color:red">RMQ-Bounce with or without apps action has Failed.</h3>
                   <table>
                   <tr>
                   <th>Job</th>
                   <th>$PROJECT_NAME</th>
                   </tr>
                   <tr>
                   <th>Triggered User</th>
                   <th>$BUILD_USER_ID</th>
                   </tr>
                   <tr>
                   <th>Job URI</th>
                   <th>$BUILD_URL</th>
                   </tr>
                   <tr>
                   <th>Envrionment</th>
                   <th>$Env</th>
                   </tr>
                   <tr>
                   <th>RabbitMQ Host</th>
                   <th>$HOST</th>
                   </tr>
                   <tr>
                   <th>ACTION</th>
                   <th>$ACTION</th>
                   </tr>
                   </table>
              </td>
              </tr>
              </table>
               <table border="1" width="900" height="100" >
                   <tr>
                     <td text="white" align="left"><p><h3>RMQ-Bounce with or without apps Job </h3>
                     <b style="color:red">Failed
                     </td>
                   </tr>
              </table>
              '''  ,
                    to: "pes-awx-prod@group.apple.com",
                    mimeType: 'text/html',
                    subject: '${DEFAULT_SUBJECT}',
                    replyTo: '$DEFAULT_REPLYTO'
        }
        success {
            emailext body:
            '''
                    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
              <html>
              <head><title></title>
              <style>
              table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 100%;
              }

              td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
              }

              tr:nth-child(even) {
                background-color: #dddddd;
              }
              </style>
              </head>
              <body>
               </table>
               <table border="2" cellpadding="0" cellspacing="0"  width="900" height="100"  bgcolor="#424242">
                <tr >
                   <th text="white" align="left"><H1 style="color:white;" align="center" >RMQ-Bounce with or without apps  Job Notification</H1> </th>
                </tr>
               </table>
               <table border="1" width="900" height="100" >
                 <tr>
                   <td text="red" align="left"><p><h3  style="color:green">RMQ-Bounce with or without apps Job has Completed Successfuly.</h3>
                   <table>
                   <tr>
                   <th>Job</th>
                   <th>$PROJECT_NAME</th>
                   </tr>
                   <tr>
                   <th>Triggered User</th>
                   <th>$BUILD_USER_ID</th>
                   </tr>
                   <tr>
                   <th>Job URI</th>
                   <th>$BUILD_URL</th>
                   </tr>
                   <tr>
                   <th>Envrionment</th>
                   <th>$Env</th>
                   </tr>
                   <tr>
                   <th>RabbitMQ Host</th>
                   <th>$HOST</th>
                   </tr>
                   <tr>
                   <th>ACTION</th>
                   <th>$ACTION</th>
                   </tr>
                  </table>
              </td>
              </tr>
              </table>
               <table border="1" width="900" height="100" >
                   <tr>
                     <td text="white" align="left"><p><h4>RabbitMQ Bounce</h4>
                     <b style="color:green">200 - Success
                     </td>
                   </tr>
              </table>
      ''',
                    to: "pes-awx-prod@group.apple.com",
                    mimeType: 'text/html',
                    subject: '${DEFAULT_SUBJECT}',
                    replyTo: '$DEFAULT_REPLYTO'
        }
        aborted {
            emailext body:
            '''
                    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
              <html>
              <head><title></title>
              <style>
              table {
                font-family: arial, sans-serif;
                border-collapse: collapse;
                width: 100%;
              }

              td, th {
                border: 1px solid #dddddd;
                text-align: left;
                padding: 8px;
              }

              tr:nth-child(even) {
                background-color: #dddddd;
              }
              </style>
              </head>
              <body>
               </table>
               <table border="2" cellpadding="0" cellspacing="0"  width="900" height="100"  bgcolor="#424242">
                <tr >
                   <th text="white" align="left"><H1 style="color:white;" align="center" > RMQ-Bounce with or without apps Job Notification</H1> </th>
                </tr>
               </table>
               <table border="1" width="900" height="100" >
                 <tr>
                   <td text="red" align="left"><p><h3  style="color:brown">RMQ-Bounce with or without apps Job aborted.</h3>
                  <table>
                   <tr>
                   <th>Job</th>
                   <th>$PROJECT_NAME</th>
                   </tr>
                   <tr>
                   <th>Triggered User</th>
                   <th>$BUILD_USER_ID</th>
                   </tr>
                   <tr>
                   <th>Job URI</th>
                   <th>$BUILD_URL</th>
                   </tr>
                   <tr>
                   <th>Envrionment</th>
                   <th>$Env</th>
                   </tr>
                   <tr>
                   <th>RabbitMQ Host</th>
                   <th>$HOST</th>
                   </tr>
                   <tr>
                   <th>ACTION</th>
                   <th>$ACTION</th>
                   </tr>
                  </table>
              </td>
              </tr>
              </table>
               <table border="1" width="900" height="100" >
                   <tr>
                     </td>
                   </tr>
              </table>
      ''',
                    to: "pes-awx-prod@group.apple.com",
                    mimeType: 'text/html',
                    subject: '${DEFAULT_SUBJECT}',
                    replyTo: '$DEFAULT_REPLYTO'
        }
    }
}
