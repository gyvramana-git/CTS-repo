pipeline{
    agent { label 'master' }
    stages {
       stage('Checkin ACM') {
            steps {
                withCredentials([usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass')])
                {
                sh '''
                set +x
                rm -rf /ngs/app/dsat/jenkins/ansible-control-machine/
                cd /ngs/app/dsat/jenkins/
                git clone https://${token_pass}@github.pie.apple.com/conduit/ansible-control-machine.git
                set -x
                '''
                echo "Ansible-control-machine is updated to latest"
                }

            }
        }
    }
}
