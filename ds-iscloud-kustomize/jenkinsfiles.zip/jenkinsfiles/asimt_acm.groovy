pipeline {
    agent none
    stages {
        stage('checkout ACM') {
            agent { label 'ma-asimt-lapp22' }
            steps {
                withCredentials([usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass')])
                {
                sh '''
                set +x
                rm -rf /ngs/app/asimt/jenkins/ansible-control-machine/
                cd /ngs/app/asimt/jenkins/
                git clone https://${token_pass}@github.pie.apple.com/conduit/ansible-control-machine.git
                set -x
                '''
                echo "Ansible-control-machine is updated to latest"
            }
        }
    }
    }
}
