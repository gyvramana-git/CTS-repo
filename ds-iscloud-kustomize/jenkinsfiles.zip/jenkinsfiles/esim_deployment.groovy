currentBuild.displayName = "$Application-$env.Environment-$grp-#"+currentBuild.number

pipeline{
    agent { label 'master' }

stages {
        stage('Initialize') {
            steps {
                echo "Playbook : $Application"
                echo "Env: $Environment"
            }
        }
        stage('Validate parameters') {
            steps{
                script{
                if ("$Environment" == '' ||  "$Application" == ''  ||   "$grp" == ''  ||  "$build_version" == ''  ||  "$ACTION" == '' ){

                    echo " Invalid Parameters Please Validate"
                    currentBuild.result = 'FAILURE'
                    error("Build failed please validate parameters.....")
                }
                else{
                     echo " Parameters Looks good "
                }
                }

            }

        }
        stage('Checkin Vault') {
            steps{
                withCredentials([usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'esim_qa_vault_pwd', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')])
                {
                    script {
                        if (env.Environment!='ncit2'){
                            sh """
                                set +x
                                sed -i -e "s/git_token/${token_pass}/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                sed -i -e "s/ansible_vault/${vault_password}/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                sed -i -e "s/memcached_port/${memcached_password}/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                set -x
                            """
                            echo "Vault Credentials are Updated"
                        }
                    }
                }
                withCredentials([usernamePassword(credentialsId: 'nitroapi', usernameVariable: 'nitro_user', passwordVariable: 'nitro_pass'), usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'vault_token', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')])
                {
                    script {
                        if (env.Environment=='ncit2'){
                            sh """
                                set +x
                                sed -i -e "s/git_token/${token_pass}/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                sed -i -e "s/ansible_vault/${vault_password}/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                sed -i -e "s/memcached_port/${memcached_password}/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                set -x
                            """
                            echo "Vault Credentials are Updated"
                        }
                    }
                }
            }

        }

        stage('Deploymemt') {
            steps {
                    withCredentials([usernamePassword(credentialsId: 'nitroapi', usernameVariable: 'nitro_user', passwordVariable: 'nitro_pass'), usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'vault_token', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')]) {
                        script{
                            if (env.Environment=='ncit2'){
                                sh '''
                                set +x

                                if [ "${EnableDebug}" = true ]
                				then
                    				echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                               		ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e int_netscaler="" -e ext_netscaler="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncit2" --limit ncit2_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncit2/hosts/hosts -e action="$action"
                                else
                    				echo "Running without debug logs"
                    				echo ${Application}
                    				echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e int_netscaler="" -e ext_netscaler="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncit2" --limit ncit2_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncit2/hosts/hosts -e action="$action"
                               		/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e int_netscaler="" -e ext_netscaler="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncit2" --limit ncit2_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncit2/hosts/hosts -e action="$action"
								fi

                                set -x
                                '''
                            }
                        }
                    }

                withCredentials([usernamePassword(credentialsId: 'nitroapi', usernameVariable: 'nitro_user', passwordVariable: 'nitro_pass'), usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'esim_qa_vault_pwd', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')])
                {
                script{
                if (env.Environment=='ncqa4'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id="" -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncqa4" --limit ncqa4_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncqa4/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id="" -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncqa4" --limit ncqa4_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncqa4/hosts/hosts -e action="$action"
					/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id="" -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncqa4" --limit ncqa4_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncqa4/hosts/hosts -e action="$action"
                fi

                set -x
                '''
                }
                else if (env.Environment=='ncit'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncit" --limit ncit_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncit/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncit" --limit ncit_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncit/hosts/hosts -e action="$action"
                	/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncit" --limit ncit_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncit/hosts/hosts -e action="$action"
				fi

                set -x
                '''
                }
                else if (env.Environment=='ncqa5'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e int_netscaler="" -e ext_netscaler="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncqa5" --limit ncqa5_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncqa5/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e int_netscaler="" -e ext_netscaler="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncqa5" --limit ncqa5_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncqa5/hosts/hosts -e action="$action"
					/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e int_netscaler="" -e ext_netscaler="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncqa5" --limit ncqa5_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncqa5/hosts/hosts -e action="$action"
				fi

                set -x
                '''
                }
                else if (env.Environment=='ncut'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncut" --limit ncut_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncut/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncut" --limit ncut_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncut/hosts/hosts -e action="$action"
                	/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncut" --limit ncut_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncut/hosts/hosts -e action="$action"

                fi

                set -x
                '''
                }
                else if (env.Environment=='ncmaint'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncmaint" --limit ncmaint_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncmaint/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncmaint" --limit ncmaint_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncmaint/hosts/hosts -e action="$action"
                	/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="ncmaint" --limit ncmaint_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/ncmaint/hosts/hosts -e action="$action"
				fi

                set -x
                '''
                }
                else if (env.Environment=='qa3'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa3" --limit qa3_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa3/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa3" --limit qa3_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa3/hosts/hosts -e action="$action"
               			/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa3" --limit qa3_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa3/hosts/hosts -e action="$action"
                fi

                set -x
                '''
                }
                else if (env.Environment=='qa1'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa1" --limit qa1_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa1/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa1" --limit qa1_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa1/hosts/hosts -e action="$action"
					/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa1" --limit qa1_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa1/hosts/hosts -e action="$action"
				fi

                set -x
                '''
                }
                else if (env.Environment=='qa2'){
                sh '''
                set +x

                if [ "${EnableDebug}" = true ]
                then
                    echo "Running with debug logs enabled and verbosity ${VerbosityLevel}"
                	ANSIBLE_DEBUG=true ANSIBLE_VERBOSITY=${VerbosityLevel} /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa2" --limit qa2_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa2/hosts/hosts -e action="$action"
                else
                    echo "Running without debug logs"
                    echo ${Application}
                    echo /ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa2" --limit qa2_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa2/hosts/hosts -e action="$action"
                	/ngs/app/dsat/jenkins/ansible/python/bin/ansible-playbook /ngs/app/dsat/jenkins/ansible-control-machine/playbooks/$Application.yml -u dst -e grp=${grp} -e pod="QA" -e shield_id="" -e shield_pass="" -e Application=$Application -e ${Application}_version=${build_version} -e cr_number="" -e ticket_id=""  -e nitro_user=$nitro_user -e nitro_pass=$nitro_pass -e @"/ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json" -e Environment="qa2" --limit qa2_${Application}_${grp} -i /ngs/app/dsat/jenkins/ansible-control-machine/environments/QA/qa2/hosts/hosts -e action="$action"
				fi

                set -x
                '''
                }
                }
                echo "Deployment is Completed"
                }

            }
        }
        stage('Remove Vault Creds')
        {
            steps {
                withCredentials([usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'esim_qa_vault_pwd', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')])
                {
                    script {
                        if (env.Environment!='ncit2'){
                            sh '''
                                set +x
                                sed -i -e "s/${token_pass}/git_token/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                sed -i -e "s/${vault_password}/ansible_vault/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                sed -i -e "s/${memcached_password}/memcached_port/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                                set -x
                            '''
                            echo "Removed Vault Credentials"
                        }
                    }
                }
                withCredentials([usernamePassword(credentialsId: 'nitroapi', usernameVariable: 'nitro_user', passwordVariable: 'nitro_pass'), usernamePassword(credentialsId: 'token', usernameVariable: 'token_id', passwordVariable: 'token_pass'), string(credentialsId: 'vault_token', variable: 'vault_password'), string(credentialsId: 'memcached_password', variable: 'memcached_password')])
                {
                    script {
                        if (env.Environment=='ncit2'){
                            sh '''
                            set +x
                            sed -i -e "s/${token_pass}/git_token/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                            sed -i -e "s/${vault_password}/ansible_vault/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                            sed -i -e "s/${memcached_password}/memcached_port/g" /ngs/app/dsat/jenkins/ansible-control-machine/vault_pass.json
                            set -x
                        '''
                        echo "Removed Vault Credentials (if it2)"
                        }
                    }
                }
            }
        }
        stage('App Status')
        {
            steps {
                echo "Playbook : $Application"
                echo "Env: $Environment"
            }

        }
}
}
